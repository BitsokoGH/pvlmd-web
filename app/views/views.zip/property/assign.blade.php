@extends('layout.default')

@section('title')
Property Assignment
@stop

@section('content')

<div class="page-content">
    <div class="col-xlg-6 col-md-6">
    </div>
    <div class="col-xlg-6 col-md-6">
         {{ Form::open(array('url'=> 'propertyassign','method'=>'post')) }}
            <div class="search"><input type="text" name="q" id="q" placeholder="User Search" /> <input type="button" id="btnsearch" value="Search User"/></div>
            <div id="searchuser">
            </div>
          <input type="submit" id="" value="Assign User"/>
            <input type="hidden" name="property" value="{{$property->id}}" />
        </form>
    </div>
</div>

@stop
@section('script')
<script type="text/javascript">
    var url = "{{URL::to('propertysearch')}}?q=";
    $("#btnsearch").click(function () {
       
        $.ajax({url: url + $("#q").val(), success: function (result) {

                $("#searchuser").html(result);
            }});
    });
</script>

@stop