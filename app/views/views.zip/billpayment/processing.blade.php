@extends('layout.default')

@section('title')
Bill Payment - {{$user->lastname}} {{$user->firstname}}
@stop

@section('content')
     
            <div class="page-content">
                <div class="panel panel-bordered">
                    <div class="panel-heading">
                        <h3 class="panel-title">Property Rent Payments</h3>
                    </div>
                    <div class="panel-body">
                        <div class="col-xlg-3 col-md-12">
                            <div class="row height-full">
                                <div class="col-xlg-12 col-md-4" >
                                    <img src="../../assets/images/{{$type}}.jpg"  alt="lands commission" class="center-block"/> 
                                    <div class="text-center">Lands Commission</div>
                                </div>
                                <div class="col-xlg-12 col-md-8" style="border-left:1px solid #e4eaec" >
  <form autocomplete="off">
                    
                    <div class="form-group">
                      <label class="control-label">Select Property</label>
                      <div >
                        <select class="form-control">
                    <option>Select an option</option>
                    <option>Plot 105, Labone Estate</option>
                    <option>Plot 207, Cantonment</option>
                  </select>
                        
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label">Amount to be Paid</label>
                      <div >
                          <h4>GHS 120.00</h4> 
                        
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label">Select Payment Option</label>
                      <div >
                  <select class="form-control">
                    <option>Select an Option</option>
                    @foreach($wallet as $wal)
                    <option value="{{$wal->id}}">{{$wal->mobile_provider}} = {{$wal->wallet_no}}</option>
               
                    @endforeach
                  </select>
                        
                      </div>
                    </div>
                    
                    <div class="form-group">
                      <button type="button" class="btn btn-primary">Make Payment</button>
                    </div>
                  </form>
                                </div>

                            </div></div>
                    </div>
                </div>   




            </div>
      
   
@stop
@section('script')

@stop